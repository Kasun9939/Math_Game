package maths_game;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Usercredit {
    
    String userName;
    String password;
    String privilege;
  
    
    

  
    
    // set values to the class
    
    public String getuserName()
    {
        //getting the userID variable instance
        return userName;
    }
    public String getpassword()
    {
        //getting the firstName variable instance
        return password;
    }
     public String getprivilege()
    {
        //getting the firstName variable instance
        return privilege;
    }


    
    // get values to the class
    
    
    public void setuserName(String userName)
    {
        //setting the userID variable value
        this.userName = userName;
    }
    public void setpassword(String password)
    {
        //setting the firstName variable text
        this.password = password;
    }
     public void setprivilege(String privilege)
    {
        //setting the firstName variable text
        this.privilege = privilege;
    }
  
    
}
